﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TextFile;

namespace assignment2_efaz
{

    interface IAtmosphere
    {
        Layer ChangeOzone(Ozone oz);
        Layer ChangeOxygen(Oxygen ox);
        Layer ChangeCarbon(CarbonDioxide ca);
    }

    class Thunderstrom : IAtmosphere
    {
        public Layer ChangeOzone(Ozone oz)
        { return new Ozone('Z', 0); }

        public Layer ChangeOxygen(Oxygen ox)
        {
            ox.ModifyLayer(.5,.5);
            return new Ozone('Z', 0.5);
        }

        public Layer ChangeCarbon(CarbonDioxide ca)
        { return new CarbonDioxide('C', 0); }

        private Thunderstrom() { }

        private static Thunderstrom instance = null;
        private double Remain;

        public static Thunderstrom Instance()
        {
            if (instance == null)
            {
                instance = new Thunderstrom();
            }
            return instance;
        }
    }

    class Sunshine : IAtmosphere
    {
        public Layer ChangeOzone(Ozone oz)
        { return new Ozone('Z', 0); }

        public Layer ChangeOxygen(Oxygen ox)
        {
            ox.ModifyLayer(.95, 0.05);
            return new Oxygen('X', 0.95);
        }

        public Layer ChangeCarbon(CarbonDioxide ca)
        {
            ca.ModifyLayer(.95, 0.05);
            return new CarbonDioxide('C', 0.95);
        }

        private Sunshine() { }

        private static Sunshine instance = null;
        private double Remain;
        private double Remain2;
        public static Sunshine Instance()
        {
            if (instance == null)
            {
                instance = new Sunshine();
            }
            return instance;
        }
    }

    class Other : IAtmosphere
    {
        public Layer ChangeOzone(Ozone oz)
        {
            oz.ModifyLayer(.95, 0.05);
            return new Ozone('Z',0.95);
        }

        public Layer ChangeOxygen(Oxygen ox)
        {
            ox.ModifyLayer(.9, 0.1);
            return new CarbonDioxide('C', 0.9);
        }

        public Layer ChangeCarbon(CarbonDioxide ca)
        { return new CarbonDioxide('C', 0); }

        private Other() { }

        private static Other instance = null;
        private double Remain;
        private double Remain2;
        public static Other Instance()
        {
            if (instance == null)
            {
                instance = new Other();
            }
            return instance;
        }
    }
}