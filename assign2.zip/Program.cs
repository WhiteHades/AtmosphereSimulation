﻿//Author:   Mohammed Efaz
//Date:     2023.05.05
//Title:    simulation until one gas completely perishes from the atmosphere

using System;
using TextFile;
using System.Collections.Generic;
using System.Globalization;

namespace assignment2_efaz
{
    class Program
    {
        /*public static void Main()
        {
            Console.WriteLine("Enter input file name:");
            string fileName = Console.ReadLine();

            // Read input file
            List<Layer> layers = new List<Layer>();
            using (StreamReader sr = new StreamReader(fileName))
            {
                int n = int.Parse(sr.ReadLine());
                for (int i = 0; i < n; i++)
                {
                    string[] line = sr.ReadLine().Split();
                    char type = line[0][0];
                    double thickness = double.Parse(line[1]);
                    switch (type)
                    {
                        case 'Z':
                            layers.Add(new Ozone(thickness));
                            break;
                        case 'X':
                            layers.Add(new Oxygen(thickness));
                            break;
                        case 'C':
                            layers.Add(new CarbonDioxide(thickness));
                            break;
                    }
                }
                string variables = sr.ReadLine();
                int round = 1;
                while (true)
                {
                    Console.WriteLine($"Round {round++}");
                    foreach (Layer layer in layers)
                    {
                        layer.React(variables[round % variables.Length]);
                    }
                    LayerManager.Instance.UpdateLayers();
                    if (LayerManager.Instance.RemoveEmptyLayers())
                    {
                        Console.WriteLine("A gas component has completely perished from the atmosphere!");
                        break;
                    }
                    foreach (Layer layer in LayerManager.Instance.GetLayers())
                    {
                        Console.WriteLine(layer);
                    }
                }
            }
        }
        */
        static void Main()
        {
            //populating the layer
            TextFileReader reader = new("inp.txt");

            reader.ReadLine(out string line);
            int n = int.Parse(line);
            List<Layer> layers = new();

            for (int i = 0; i < n; ++i)
            {
                char[] separators = new char[] { ' ', '\t' };
                Layer layer = null;

                if (reader.ReadLine(out line))
                {
                    string[] tokens = line.Split(separators, StringSplitOptions.RemoveEmptyEntries);

                    char ch = char.Parse(tokens[0]);
                    //string name = tokens[1];
                    double p = Double.Parse(tokens[1]);

                    switch (ch)
                    {
                        case 'Z': layer = new Ozone(ch, p); break;
                        case 'X': layer = new Oxygen(ch, p); break;
                        case 'C': layer = new CarbonDioxide(ch, p); break;
                    }
                }
                layers.Add(layer);
            }


            // populating the atmospheric variables (thunderstorm, sunshine, other)
            
            reader.ReadLine(out line);
            int lineIndex = 0;
            int round = 0;
            bool isPerished = false;
            string m = line;
            List<IAtmosphere> atmospheres = new();
            do
            {
                Console.WriteLine($"round: {++round}");
                for (int j = 0; j < layers.Count; ++j)
                {
                    //reader.ReadChar(out char c);
                    char c = m[lineIndex++ % m.Length];
                    switch (c)
                    {
                        case 'T': atmospheres.Add(Thunderstrom.Instance()); break;
                        case 'S': atmospheres.Add(Sunshine.Instance()); break;
                        case 'O': atmospheres.Add(Other.Instance()); break;
                    }
                    layers[j].Simulate(ref layers, atmospheres[round-1]);
                    if (!layers[j].NotPerish())
                    {
                        layers.RemoveAt(j);
                    }
                }
                //layers.RemoveAll(layer => layer.NotPerish());

                foreach (Layer layer in layers)
                {
                    if (layer.NotPerish())
                    {
                        Console.WriteLine($"{layer.Name} {layer.Thickness}");
                    }
                    else
                    {
                        Console.WriteLine("A gas component has completely perished from the atmosphere.");
                        isPerished = true;
                        break;
                    }
                    Console.WriteLine($"{layer.Name} {layer.Thickness}");
                }
            } while (!isPerished);




            /*
            * char c = line[lineIndex++ % line.Length];
            * This is the trick that I used, if you need to traverse when you reach to the end



           // Simulation
           try
           {
               for (int i = 0; i < m.Length; ++i)
               {
                   layers[i].Simulate(ref atmospheres);
                   if (layers[i].NotPerish())
                   {
                       Console.WriteLine($"{layers[i].Name}: {layers[i].Thickness} ");
                   }
               }
           }
           catch (Exception e)
           {
               Console.WriteLine("{0}", e.ToString());
           }
            */
        }
    }
}