﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment2_efaz
{

    abstract class Layer
    {
        public char Name { get; }
        public double Thickness;
        public void ModifyLayer(double Thickness, double Remain)
        {
            Remain = (1 - Thickness) * this.Thickness;
            this.Thickness = Thickness * this.Thickness;
            
        }
        public bool NotPerish() { return Thickness >= 0.5; }

        protected Layer(char str, double Thickness)
        {
            Name = str;
            this.Thickness = Thickness;
        }
        public void Simulate(ref List<Layer> layer, IAtmosphere atmosphere)
        {
            int index = layer.IndexOf(this);
            Layer layers = Traverse(atmosphere);
            bool islayer = false;
            if (layer[index].Thickness < 0.5)
            { 
                for (int j = index+1; j < layer.Count; ++j)
                {
                    if (layer[j].GetType == layer[index].GetType)
                    {
                        layer[j].Thickness += layer[index].Thickness + layers.Thickness;
                        islayer = true;
                        break;
                    }
                }
                layer.RemoveAt(index);
            }
            else
            {
                for (int i = index + 1; i < layer.Count; i++)
                {
                    if (layer[i].GetType() == layers.GetType())
                    {
                        layer[i].Thickness += layers.Thickness;
                        islayer = true;
                        break;
                    }
                }
            }
            if(!islayer && layers.Thickness >= 0.5)
            {
                layer.Insert(layer.Count, layers);
            }
        }
        protected abstract Layer Traverse(IAtmosphere atmosphere);
    }

    class Ozone : Layer
    {
        public Ozone(char str, double Thickness) : base(str, Thickness) { }
        protected override Layer Traverse(IAtmosphere atmosphere)
        {
            return atmosphere.ChangeOzone(this);
        }
    }

    class Oxygen : Layer
    {
        public Oxygen(char str, double Thickness) : base(str, Thickness) { }
        protected override Layer Traverse(IAtmosphere atmosphere)
        {
            return atmosphere.ChangeOxygen(this);
        }
    }

    class CarbonDioxide : Layer
    {
        public CarbonDioxide(char str, double Thickness) : base(str, Thickness) { }
        protected override Layer Traverse(IAtmosphere atmosphere)
        {
            return atmosphere.ChangeCarbon(this);
        }
    }
}